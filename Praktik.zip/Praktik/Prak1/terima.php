<?php
if(isset($_POST["simpan"])){
	$kunci=$_POST["kunci"];
	$nama=$_POST["nama"];
	$alamat=$_POST["alamat"];
	$pass=$_POST["pass"];
	if(isset($_POST["jkl"])){
		$jkl=$_POST["jkl"];
	}
	if(isset($_POST["minat"])){
		$minat=$_POST["minat"];
	}
	if(isset($_POST["minat1"])){
		$minat1=$_POST["minat1"];
	}
	if(isset($_POST["minat2"])){
		$minat2=$_POST["minat2"];
	}
	
	$progdi=$_POST["progdi"];
	$pesan=$_POST["pesan"];
	
	echo "Key-MU : ".$kunci."<br>";
	echo "Nama : ".$nama."<br>";
	echo "Alamat : ".$alamat."<br>";
	echo "Password : ".$pass."<br>";
	echo "Jenis Kelamin : ".$jkl."<br>";
	foreach($minat as $mnt){
		echo "Minat : ".$mnt."<br>";
	}
	echo "Progdy : ".$progdi."<br>";
	echo "Pesan : ".$pesan."<br>";
	echo "Tombol simpan di klik";
	
}else{
	echo "Tombol simpan tidak di klik";
	
}
?>