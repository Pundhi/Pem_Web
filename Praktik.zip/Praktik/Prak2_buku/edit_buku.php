<?php
include "koneksi.php";
$id=$_GET["id"];
$query="select * from buku where id='$id'";
$perintah=mysql_query($query);
$data=mysql_fetch_array($perintah);

echo "<h2>Edit Buku</h2>";
echo "<form method='post' action='proses_edit_buku.php'>
Id : $id <br>
Judul : <br>
<input name='judul' type='text' size='70'><br>
Pengarang : <br>
<input name='pengarang' type='text' size='70'><br>
Penerbit : <br>
<input name='penerbit' type='text' size='50'><br>
Kategori : <br>
<input name='kategori' type='text'><br>
Harga : <br>
<input name='harga' type='text' size='50'><br>

<input type='hidden' name='id' value='$id'>

<input type='submit' name='Submit' value='Koreksi'>
<input type='reset' name='Reset' value='Batal'>
</form>";
?> 
