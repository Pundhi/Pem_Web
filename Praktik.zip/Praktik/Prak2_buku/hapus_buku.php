<?php
include "koneksi.php";

$id=$_GET["id"];

$query="delete from buku where id='$id'";
$hasil=mysql_query($query);

if ($hasil){
	echo "Data berhasil dihapus <a href='tampil_buku.php'>Tampilkan Daftar Buku</a>";
}else{
	echo "Data Gagal dihapus";
}
?> 
