-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 20 Apr 2015 pada 16.50
-- Versi Server: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `perpustakaan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `buku`
--

CREATE TABLE IF NOT EXISTS `buku` (
  `id` int(11) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `pengarang` varchar(50) NOT NULL,
  `penerbit` varchar(50) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `harga` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `buku`
--

INSERT INTO `buku` (`id`, `judul`, `pengarang`, `penerbit`, `kategori`, `harga`) VALUES
(1, 'Metodologi Penelitian Sistem Informasi', 'Jogiyanto', 'Andi', 'Metode', 75000),
(2, 'The Art Of Debugging', 'Eko Dharma Pranoto', 'Andi ', 'Debug', 45000),
(3, 'Rekayaasa Perangkat Lunak', 'Rossa A.S', 'INFORMATIKA', 'Rekayasa', 55000),
(4, 'App Inventor: ciptakan sendiri aplikasi androidmu', 'Eueug Mulyana', 'Andi', 'Mobile', 50000),
(5, 'Keceerdasan Buatan', 'T.Sutojo, S.Si, M.Kom', 'Andi', 'Metode', 97000),
(6, 'Komik Anak-Anak', 'Pundhi', 'Syammara', 'Buku', 10000),
(7, 'htdh', 'hht', 'hrh', 'yhh', 54);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
