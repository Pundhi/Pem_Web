<?php 
include "koneksi.php";
$id=$_POST["id"];
$judul=$_POST["judul"];
$pengarang=$_POST["pengarang"];
$penerbit=$_POST["penerbit"];
$kategori=$_POST["kategori"];
$harga=$_POST["harga"];

$query="insert into buku(id,judul,pengarang,penerbit,kategori,harga) values('$id','$judul','$pengarang','$penerbit','$kategori','$harga')";
$hasil=mysql_query($query);

if ($hasil){
	echo "Data berhasil disimpan <a href='tampil_buku.php'>Tampilkan Daftar Buku</a>";
}else{
	echo "Data Gagal disimpan";
}
?> 
