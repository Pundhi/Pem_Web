<html>
<head>
<title>Tambah Buku</title>
</head>
<body>
<h2>Tambah Buku</h2>
<form method="post" action="proses_tambah_buku.php">
Id : <br>
<input name="id" type="text" size="20"><br>
Judul : <br>
<input name="judul" type="text" size="70"><br>
Pengarang : <br>
<input name="pengarang" type="text" size="50"><br>
Penerbit : <br>
<input name="penerbit" type="text" size="50"><br>
Kategori : <br>
<input name="kategori" type="text"><br>
Harga : <br>
<input name="harga" type="text" size="50"><br>

<input type="submit" name="Submit" value="Tambah">
<input type="reset" name="Reset" value="Batal">
</form>
</body>
</html>
