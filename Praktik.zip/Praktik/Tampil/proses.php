<?php
require_once("koneksi.php");
$nama = $_POST['nama'];
$nim = $_POST['nim'];
$jkl = $_POST['jkl'];
if(!$nama || !$nim || !$jkl) {
echo "Masih ada data yang kosong!<br/>";
echo "<a href='Index.php'> Back </a>";
} else {
$simpan = mysql_query("INSERT INTO mahasiswa(nama, nim, jkl) VALUES('$nama','$nim','$jkl')");
if($simpan) {
	echo "Nama :$nama<br/>";
	echo "Nim :$nim<br/>";
	echo "Jenis Kelamin :$jkl<br/>";
	echo "<a href='Index.php'>  Back </a>";
} else {
echo "Proses Gaga!";
}
}
?>