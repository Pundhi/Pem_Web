<?php
include "koneksi.php";
$no=$_GET["no"];
// $nama=$_GET["nama"];
// $alamat=$_GET["alamat"];

$query="select * from peminjam where no='$no'";
$perintah=mysql_query($query);
$data=mysql_fetch_array($perintah);

echo "<h2>Edit Peminjam</h2>";
echo "<form method='post' action='proses_edit_peminjam.php'>

No : $no <br>
Nama : <br>
<input type='text' name='nama' value='$data[nama]'><br>
Alamat : <br>
<input type='text' name='alamat' value='$data[alamat]'><br>

<input type='hidden' name='no' value='$no'>

<input type='submit' name='Submit' value='Koreksi'>
<input type='reset' name='Reset' value='Batal'>
</form>";
?> 
