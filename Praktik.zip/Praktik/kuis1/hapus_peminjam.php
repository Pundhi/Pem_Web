<?php
include "koneksi.php";

$no=$_GET["no"];

$query="delete from peminjam where no='$no'";
$hasil=mysql_query($query);

header("location:tampil_peminjam.php");
?> 
