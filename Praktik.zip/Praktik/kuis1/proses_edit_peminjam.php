<?php
include "koneksi.php";
$no=$_POST["no"];
$nama=$_POST["nama"];
$alamat=$_POST["alamat"];

$query="update peminjam set no='$no', nama='$nama', alamat='$alamat' 
where no='$no', nama='$nama', alamat='$alamat'";
$hasil=mysql_query($query);

header("location:tampil_peminjam.php");
?> 
