<?php 
include "koneksi.php";
$no=$_POST["no"];
$nama=$_POST["nama"];
$alamat=$_POST["alamat"];

$query="insert into peminjam(no, nama, alamat)
values('$no','$nama','$alamat')";
$hasil=mysql_query($query);

if ($hasil){
	echo header("location:tampil_peminjam.php");
}else{
	echo "Data Gagal disimpan";
}
?> 
