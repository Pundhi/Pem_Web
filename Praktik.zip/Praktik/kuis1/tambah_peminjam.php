<!!doc html>
<head>
<title>Tambah Buku</title>
</head>
<body>
<h2>Tambah Buku</h2>
<form method="post" action="proses_tambah_peminjam.php">
No : <br>
<input name="no" type="text" size="20" required><br>
Nama : <br>
<input name="nama" type="text" size="20" required><br>
Alamat : <br>
<input name="alamat" type="text" size="20" required><br>


<input type="submit" name="Submit" value="Tambah">
<input type="reset" name="Reset" value="Batal">
</form>
</body>
</html>
