<script language="javascript">
function confirm_hapus()
{
	ok=confirm('Anda yakin ingin menghapus?')
	if (ok){
	  return true;
	}else{
	  return false;
	}
}
</script>
<?php 
// sertakan file koneksi.php
include "koneksi.php";

// perintah query
$query="select * from peminjam";
$perintah=mysql_query($query);

echo "<h2>Daftar Peminjam</h2>
	  <table border=1>
	  <tr>
  <th>NO</th>
  <th>NAMA</th>
  <th>ALAMAT</th>
	  </tr>";
// tampilkan data
while ($data=mysql_fetch_array($perintah))
{
	echo "<tr>		  
			<td>$data[no]</td>
			<td>$data[nama]</td>
			<td>$data[alamat]</td>
	        <td> <a href=edit_peminjam.php?no=$data[no]>edit</a> | 
	        <a href=hapus_peminjam.php?no=$data[no] onclick='return confirm_hapus()'>hapus</a></td>
	  </tr>";
}
echo "</table><br>";
echo "<a href='tambah_peminjam.php'>Tambahkan Peminjam</a>";
?> 
