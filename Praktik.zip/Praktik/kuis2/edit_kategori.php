<?php
include "koneksi.php";
$id=$_GET["id_kategori"];


$query="select * from kategori where id_kategori='$id'";
$perintah=mysql_query($query);
$data=mysql_fetch_array($perintah);

echo "<h2>Edit Kategori</h2>";
echo "<form method='post' action='proses_edit_kategori.php'>

No : $id <br>
Nama : <br>
<input type='text' name='nama_kategori' value='$data[nama_kategori]'><br>


<input type='hidden' name='id_kategori' value='$data[id_kategori]'>

<input type='submit' name='Submit' value='Koreksi'>
<input type='reset' name='Reset' value='Batal'>
</form>";
?> 
