<?php
include "koneksi.php";
$id=$_GET["id_kategori"];

$query="delete from kategori where id_kategori='$id'";
$hasil=mysql_query($query);

header("location:tampil_kategori.php");
?> 
