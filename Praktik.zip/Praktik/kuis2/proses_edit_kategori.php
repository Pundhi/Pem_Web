<?php
include "koneksi.php";
$id=$_POST["id_kategori"];
$nama=$_POST["nama_kategori"];

$query="update kategori set id_kategori='$id', nama_kategori='$nama' 
where id_kategori='$id', nama_kategori='$nama'";
$hasil=mysql_query($query);

header("location:tampil_kategori.php");
?> 
