<?php 
include "koneksi.php";
$id=$_POST["id_kategori"];
$nama=$_POST["nama_kategori"];

$query="insert into kategori(id_kategori, nama_kategori)
values('$id','$nama')";
$hasil=mysql_query($query);

if ($hasil){
	echo header("location:tampil_kategori.php");
}else{
	echo "Data Gagal disimpan";
}
?> 
