


<!!doctype html>
<head>
<title>Tambah Buku</title>
</head>
<body>
<h2>Tambah Buku</h2>
<form method="post" action="proses_tambah_kategori.php">
ID : <br>
<input name="id_kategori" type="text" size="20" required><br>
Nama : <br>
<input name="nama_kategori" type="text" size="20" required><br>


<input type="submit" name="Submit" value="Tambah">
<input type="reset" name="Reset" value="Batal">
</form>
</body>
</html>
