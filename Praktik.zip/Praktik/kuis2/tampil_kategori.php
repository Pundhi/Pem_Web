<script language="javascript">
function confirm_hapus()
{
	ok=confirm('Anda yakin ingin menghapus?')
	if (ok){
	  return true;
	}else{
	  return false;
	}
}
</script>
<?php 
// sertakan file koneksi.php
include "koneksi.php";

// perintah query
$query="select * from kategori";
$perintah=mysql_query($query);

echo "<h2>Tabel Kategori</h2>
	  <table border=1>
	  <tr>
  <th>ID</th>
  <th>NAMA</th>
	  </tr>";
// tampilkan data
while ($data=mysql_fetch_array($perintah))
{
	echo "<tr>		  
			<td>$data[id_kategori]</td>
			<td>$data[nama_kategori]</td>
	        <td> <a href=edit_kategori.php?id_kategori=$data[id_kategori]>edit</a> | 
	        <a href=hapus_kategori.php?id_kategori=$data[id_kategori] onclick='return confirm_hapus()'>hapus</a></td>
	  </tr>";
}
echo "</table><br>";
echo "<a href='tambah_kategori.php'>Tambahkan Kategori</a>";
?> 
