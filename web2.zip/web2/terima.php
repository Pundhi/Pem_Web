<?php
if(isset($_POST["simpan"])){
	$kunci=$_POST["kunci"];
	$nama=$_POST["nama"];
	$alamat=$_POST["alamat"];
	$pass=$_POST["pass"];
	if(isset($_POST["jkl"])){
		$jkl=$_POST["jkl"];
	}
	if(isset($_POST["minat"])){
		$minat=$_POST["minat"];
	}
	if(isset($_POST["minat1"])){
		$minat1=$_POST["minat1"];
	}
	if(isset($_POST["minat2"])){
		$minat2=$_POST["minat2"];
	}
	$progdi=$_POST["progdi"];
	$pesan=$_POST["pesan"];
	echo $kunci.'<br>';
	echo $nama.'<br>';
	echo $alamat.'<br>';
	echo $pass.'<br>';
	echo $jkl.'<br>';
	foreach($minat as $mnt){
			echo $mnt;
			echo '<br/>';
		}
	echo $progdi.'<br>';
	echo $pesan.'<br>';
	
	echo "Tombol simpan di klik";
}else{
	echo "Tombol simpan tidak di klik";
	
}